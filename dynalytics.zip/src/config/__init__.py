"""Configuration module."""
from .settings import Settings

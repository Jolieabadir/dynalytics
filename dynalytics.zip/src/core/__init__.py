"""Core data structures."""
from .landmark import Landmark
from .angle import Angle
